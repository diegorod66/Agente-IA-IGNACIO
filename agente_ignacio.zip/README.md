# Agente IGNACIO

Asistente IA para análisis de productos y oportunidades de reventa.
